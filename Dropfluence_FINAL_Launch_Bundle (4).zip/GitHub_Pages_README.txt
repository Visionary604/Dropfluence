
# 🌐 Dropfluence GitHub Pages Setup

## Step-by-Step Guide to Launch Your Webpage

1. Go to [https://github.com](https://github.com) and open your Dropfluence repo.
2. Click **Settings** > Scroll down to **Pages**
3. Under "Source" select **main** branch and set folder to **/root** or **/docs** (if your index.html is there).
4. Click Save.

📍 Your live site will appear at:
`https://yourusername.github.io/Dropfluence/`

Just make sure `index.html` is at the root level.
